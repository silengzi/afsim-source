80
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 operator state
ENUMERATION 5 1 none
ENUMERATION 6 4 conflict constraint-failure no-change tie
SOAR_ID 7
FLOAT_RANGE 8 -Infinity Infinity
FLOAT_RANGE 9 -Infinity Infinity
FLOAT_RANGE 10 -Infinity Infinity
FLOAT_RANGE 11 -Infinity Infinity
FLOAT_RANGE 12 -Infinity Infinity
FLOAT_RANGE 13 -Infinity Infinity
SOAR_ID 14
FLOAT_RANGE 15 -Infinity Infinity
SOAR_ID 16
ENUMERATION 17 1 initialize-ripr-aigci
ENUMERATION 18 1 elaboration
SOAR_ID 19
STRING 20
SOAR_ID 21
INTEGER_RANGE 22 -2147483648 2147483647
STRING 23
SOAR_ID 24
SOAR_ID 25
ENUMERATION 26 1 pursue-target
SOAR_ID 27
STRING 28
STRING 29
STRING 30
SOAR_ID 31
ENUMERATION 32 1 wait
SOAR_ID 33
INTEGER_RANGE 34 -2147483648 2147483647
SOAR_ID 35
STRING 36
STRING 37
FLOAT_RANGE 38 -Infinity Infinity
FLOAT_RANGE 39 -Infinity Infinity
FLOAT_RANGE 40 -Infinity Infinity
FLOAT_RANGE 41 -Infinity Infinity
FLOAT_RANGE 42 -Infinity Infinity
STRING 43
SOAR_ID 44
STRING 45
ENUMERATION 46 1 nil
FLOAT_RANGE 47 -Infinity Infinity
FLOAT_RANGE 48 -Infinity Infinity
FLOAT_RANGE 49 -Infinity Infinity
FLOAT_RANGE 50 -Infinity Infinity
SOAR_ID 51
STRING 52
FLOAT_RANGE 53 -Infinity Infinity
FLOAT_RANGE 54 -Infinity Infinity
FLOAT_RANGE 55 -Infinity Infinity
FLOAT_RANGE 56 -Infinity Infinity
FLOAT_RANGE 57 -Infinity Infinity
SOAR_ID 58
SOAR_ID 59
STRING 60
INTEGER_RANGE 61 -2147483648 2147483647
STRING 62
INTEGER_RANGE 63 -2147483648 2147483647
SOAR_ID 64
ENUMERATION 65 1 evade-target
FLOAT_RANGE 66 -Infinity Infinity
SOAR_ID 67
SOAR_ID 68
STRING 69
FLOAT_RANGE 70 -Infinity Infinity
FLOAT_RANGE 71 -Infinity Infinity
FLOAT_RANGE 72 -Infinity Infinity
INTEGER_RANGE 73 -2147483648 2147483647
INTEGER_RANGE 74 -2147483648 2147483647
SOAR_ID 75
ENUMERATION 76 1 evade-incoming
SOAR_ID 77
SOAR_ID 78
STRING 79
84
0 attribute 4
0 choices 5
0 impasse 6
0 io 1
0 item 44
0 name 36
0 operator 16
0 operator 25
0 operator 31
0 operator 64
0 operator 75
0 stale-time 47
0 superstate 46
0 top-state 7
1 input-link 2
1 output-link 3
2 current-time 15
2 orders-root 58
2 ownship-ammo 9
2 ownship-closing-speed-max 48
2 ownship-closing-speed-min 49
2 ownship-corner-speed 12
2 ownship-engagement-range-max 11
2 ownship-engagement-range-min 10
2 ownship-speed 8
2 ownship-speed-max 13
2 ownship-threat-tolerance 66
2 ownship-weapons-incoming 74
2 track-root 14
2 weight-closing-speed-of 55
2 weight-current-target 57
2 weight-others-targeting 72
2 weight-slant-range-to 54
3 do-nothing 21
3 pursue-target 24
14 target 19
16 name 17
16 random 18
19 closing-speed-of 40
19 currently-targeted 56
19 others-targeting 73
19 positioning 43
19 relative-bearing-to 38
19 slant-range-to 42
19 speed 41
19 target-name 20
19 target-type 62
19 threat-level 71
19 update-time 39
19 weapons-in-flight 63
21 nothing 22
21 status 23
24 pursuit-mode 29
24 status 30
24 target-name 28
25 actions 35
25 counted 51
25 name 26
25 score 50
25 target 19
27 do-nothing 33
31 actions 27
31 name 32
33 nothing 34
33 status 37
35 pursue-target 24
44 actions 35
44 name 45
44 target 19
51 name 52
51 value 53
58 prefer-target-type 59
59 target-type 60
59 weight 61
64 actions 67
64 name 65
64 target 19
67 evade-target 68
68 target-name 69
68 threat-level 70
75 actions 77
75 name 76
77 evade-incoming 78
78 target-name 79
