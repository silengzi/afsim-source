..\..\..\bin\sage coordinated_strike.txt > output\std_output.txt
